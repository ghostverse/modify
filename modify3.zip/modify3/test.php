<?php

require 'vendor/autoload.php';
use g66k\smtpChecker;


$str = 'https://google.com/q=##base64##(##date##)/##base64##(##domain##)';

$smtp = new smtpChecker();

$whats = $smtp->replace($str, 'google@google3.com');

echo $whats . "\n";