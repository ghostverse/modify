<?php


namespace g66k;


class Config
{
        public static $configuration = [
              'SMTP' => [
                [
                 'host' => 'smtp-relay.gmail.com',
                'port' => 587,
                'username' => 'chris@udara-dingin.website',
                'password' => 'Dubai@2020',
                'enc' => 'tls',
                'auth' => true,
                ],
         [
                 'host' => 'smtp-relay.gmail.com',
                'port' => 587,
                'username' => 'raymond@udara-dingin.website',
                'password' => 'Dubai@2020',
                'enc' => 'tls',
                'auth' => true,
                ],
         [
                 'host' => 'smtp-relay.gmail.com',
                'port' => 587,
                'username' => 'harry@udara-dingin.website',
                'password' => 'Dubai@2020',
                'enc' => 'tls',
                'auth' => true,
                ],
         [
                 'host' => 'smtp-relay.gmail.com',
                'port' => 587,
                'username' => 'elim@udara-dingin.website',
                'password' => 'Dubai@2020',
                'enc' => 'tls',
                'auth' => true,
                ],
         [
                 'host' => 'smtp-relay.gmail.com',
                'port' => 587,
                'username' => 'steel@udara-dingin.website',
                'password' => 'Dubai@2020',
                'enc' => 'tls',
                'auth' => true,
                ],
         [
                 'host' => 'smtp-relay.gmail.com',
                'port' => 587,
                'username' => 'kent@udara-dingin.website',
                'password' => 'Dubai@2020',
                'enc' => 'tls',
                'auth' => true,
                ],
         [
                 'host' => 'smtp-relay.gmail.com',
                'port' => 587,
                'username' => 'clark@udara-dingin.website',
                'password' => 'Dubai@2020',
                'enc' => 'tls',
                'auth' => true,
                ],             
            ],

            'SENDER' => [
                'subject' => '##date##',
                'fromname' => '##domainname##-{I-{Tele-Mail}} from ##number3##-{##number1####number2##}-XXXX',
                'masking' => 1,
                'fromemail' => ['orders-no-reply@chownow.com'],
                'letter' => 'fm.html',
                'enableletterencrypter' => 1,
                'lettertoencrypt' => 'FileAttachment.html',
                'emails' => 'mail.txt',
                'link' => 'http://www.google.com'
            ],
            'CONFIG' => [
                'timezone' => 'America/New_York',
                'blacklist' => 0,
                'sleeptime' => 2,
                'maillimit' => 0,
                'delaylimit' => 0,
                'thread' => 1,
                'encryptfromname' => 0,
                'encryptsubject' => 0,
                'maskingemail' => 0,
                'emailtest' => 0,
                'testevery' => 500,
                'testemail' => 'cmelendez@flaflcio.org',
                'defaultLogo' => 'defaultLogo.png'
            ],

            'ATTACHMENT' => [
                'sendattachment' => 1,
                'htmlattachment' => 1,
                'fileattachment' => 'AttachmentCode.html',
                'nameattachment' => 'TELEFAX_##domainname####CHAR3####number3####CHAR3####number2####CHAR2####number1####CHAR2##.HTM',
                'enableimage' => 0,
                'image' => [ 'logo' => 'use.png' , 'logo2' => 'image.png'],
                'embedimage' => 1,
                'html2image' => 'html2image.html',
                'embedimagename' => 'name.png'
            ]
        ];
        public static function get($name)
        {
            return self::$configuration[$name];
        }
}