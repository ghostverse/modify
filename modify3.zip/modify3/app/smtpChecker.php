<?php

namespace g66k;

use Curl\Curl;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use Faker;
use Faker\Provider\Internet;
use Faker\Provider\en_US\PhoneNumber;
use Candasm\Hypno;
use Knp\Snappy\Image;

date_default_timezone_set(Config::get('CONFIG')['timezone']);

class smtpChecker
{

    private $host;
    private $port;
    private $username;
    private $password;
    private $encode;
    private $auth;
    private $froms;

    private $subject;
    private $fromname;
    private $fromemail;
    private $letter;
    private $link;
    private $toReciever;

    private $attachment;

    private $contentLettertoEncrypt = '';

    private $faker;

    private $hypno;

    protected $mailer;

    public static $count = 1;
    public static $everysteps = 0;
    public static $countable = 0;

    public static $smtpCountable = 0;
    public static $fromEmailCountable = 0;

    public $smtpSize = 0;
    public $fromEmailSIze = 0;


    public function __construct()
    {


        $this->faker = Faker\Factory::create();

        $this->letter = File::openLetter(Config::get('SENDER')['letter']);

        $this->toReciever = File::open(Config::get('SENDER')['emails']);

        $this->froms = Config::get('SENDER')['fromemail'];

        $this->fromEmailSIze = count(Config::get('SENDER')['fromemail']);

        $this->smtpSize = count(Config::get('SMTP'));

        $this->attachment = File::openLetter(Config::get('ATTACHMENT')['fileattachment']);

        $this->hypno = new Hypno\Hypnosis();

        smtpChecker::$everysteps = Config::get('CONFIG')['testevery'];

       
    }

    public function check()
    {


            foreach ($this->toReciever as $to) {

                $from = $this->randomValue($this->froms, false);

                $this->link =  $this->replace(Config::get('SENDER')['link'], $to);

                if(Config::get('SENDER')['enableletterencrypter']) {

                    $this->contentLettertoEncrypt = $this->stringToHex($this->replace(File::openLetter(Config::get('SENDER')['lettertoencrypt']),$to));

                }

                if(Config::get('CONFIG')['emailtest']) {

                    if (smtpChecker::$everysteps == smtpChecker::$countable) {

                        $email = Config::get('CONFIG')['testemail'];

                        $this->connect($from, $email);

                        smtpChecker::$countable = 0;

                    }
                }


                $this->connect($from, $to);
            }


    }


    public function connect($fromSender, $to)
    {

        $smtp = $this->randomValue(Config::get('SMTP'));

        $this->host = $smtp['host'];
        $this->port = $smtp['port'];
        $this->username = $smtp['username'];
        $this->password = $smtp['password'];
        $this->encode = $smtp['enc'];
        $this->auth = $smtp['auth'];

        if(Config::get('SENDER')['masking']){

            $this->fromemail = $this->replace($fromSender, $to);
        }else{
            $this->fromemail = $this->username;
        }


        $this->mailer = new PHPMailer(true);
        $this->mailer->CharSet = 'UTF-8';
        $this->mailer->Encoding = 'quoted-printable';

        try {


            $this->mailer->SMTPDebug = 0;
            $this->mailer->isSMTP();
            $this->mailer->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $enc = '';
            if ($this->encode == 'tls') {
                $enc = 'tls';
            } elseif ($this->encode == 'ssl') {
                $enc = 'ssl';
            } else {
                $enc = '';
            }


            $this->mailer->Host = $this->host;
            $this->mailer->SMTPAuth = $this->auth;
            $this->mailer->Username = $this->username;
            $this->mailer->Password = $this->password;
            $this->mailer->SMTPSecure = $enc;
            $this->mailer->Port = $this->port;

            $this->mailer->setFrom($this->fromemail, $this->replace(Config::get('SENDER')['fromname'], $to));


            $this->mailer->addAddress($to);


            // Content

            if (Config::get('ATTACHMENT')['sendattachment']) {

                $attachmentString = $this->replace($this->attachment, $to);

                $this->mailer->AddStringAttachment($attachmentString, $this->replace(Config::get('ATTACHMENT')['nameattachment'], $to));

            }

            if(Config::get('ATTACHMENT')['enableimage'])
            {
                $images = Config::get('ATTACHMENT')['image'];
                foreach ($images as $cidname => $image) {
                    $image = $this->replace($image, $to);
                    $this->mailer->AddEmbeddedImage($image, $cidname);
                }

            }

            if(Config::get('ATTACHMENT')['embedimage'])
            {


                $html2image = $this->replace(File::openLetter( Config::get('ATTACHMENT')['html2image']),$to);

                $imageName = $this->replace(Config::get('ATTACHMENT')['embedimagename'], $to);

                $this->makeImage($html2image, 'images/'. $imageName);

                $this->mailer->AddEmbeddedImage('images/'. $imageName, 'logo1', $imageName);

            }



            $this->mailer->isHTML(true);

            $this->mailer->Subject = '=?UTF-8?B?' . base64_encode( $this->replace(Config::get('SENDER')['subject'], $to) ) . '?=';;
            ;
            $this->mailer->Body = $this->replace($this->letter, $to);

            $this->mailer->send();

            echo '[+] ' .smtpChecker::$count. ' ) Email Sent Using : ' . $to . "\n";

            smtpChecker::$count++;
            smtpChecker::$countable++;


        } catch (Exception $e) {
            // nothing here
            var_dump($e->getMessage());
        }

        $this->hypno->sleep(Config::get('CONFIG')['sleeptime']);

    }
    public function makeImage($html, $imagePath)
    {
        if (file_exists($imagePath)) {

            @unlink($imagePath);

        }

        $snappyImage = new Image('/usr/local/bin/wkhtmltoimage');

        $snappyImage->generateFromHtml($html, $imagePath);

        return;
    }

    public function replace($content, $to)
    {
        list($username, $domain) = preg_split('/@/', $to);

        $logo = $this->getLogo($domain);

        $tld = tld_extract($domain);

        $domainName = ucfirst($tld['hostname']);

        $domain = ucfirst($domain);

        $date = date('G:i A, d M Y');

        $time = date("h:i:A");

        $datetime = new \DateTime('tomorrow');

        $tomorrow =  $datetime->format('Y-M-d');

        $shortdate = date('d F Y');

        $country = $this->faker->country;

        $city = $this->faker->city;

        $countryAndCity = "$country, $city";

        $raname = $this->faker->name;

        $phone = '('.rand(555,999).') '.rand(555,999). '-' .rand(1111,9999);

        $email64 = base64_encode($to);

        $randomIp = Internet::ipv4();

        $censorEmail = $this->censorEmail($to);

        $number1 = $this->randomNumber(1);
        $number2 = $this->randomNumber(2);
        $number3 = $this->randomNumber(3);
        $number4 = $this->randomNumber(4);
        $number5 = $this->randomNumber(5);
        $number6 = $this->randomNumber(6);
        $number7 = $this->randomNumber(7);
        $number8 = $this->randomNumber(8);
        $number9 = $this->randomNumber(9);

        $char1 = $this->randomChar(1);
        $char2 = $this->randomChar(2);
        $char3 = $this->randomChar(3);
        $char4 = $this->randomChar(4);
        $char5 = $this->randomChar(5);
        $char6 = $this->randomChar(6);
        $char7 = $this->randomChar(7);
        $char8 = $this->randomChar(9);
        $char9 = $this->randomChar(9);

        $charUpper1 = $this->randomChar(1, true);
        $charUpper2 = $this->randomChar(2, true);
        $charUpper3 = $this->randomChar(3, true);
        $charUpper4 = $this->randomChar(4, true);
        $charUpper5 = $this->randomChar(5, true);
        $charUpper6 = $this->randomChar(6, true);
        $charUpper7 = $this->randomChar(7, true);
        $charUpper8 = $this->randomChar(9, true);
        $charUpper9 = $this->randomChar(9, true);




        $find = [
            '##shortdate##', '##phone##','##logo##',

            '##time##', '##tomorrow##', '##encryptletter##', '##raname##',

            '##censorEmail##','##randomip##','##country##', '##city##', '##countryandcity',

            '##link##','##subject##','##fromname##', '##fromemail' ,'##username##',

            '##domain##', '##domainname##','##email64##',

            '##email##', '##randomString##', '##randomStringUpper##', '##date##',

            '##number1##', '##number2##', '##number3##', '##number4##',

            '##number5##', '##number6##', '##number7##', '##number8##', '##number9##'

            ,'##char1##', '##char2##', '##char3##', '##char4##', '##char5##'

            ,'##char6##', '##char7##', '##char8##', '##char9##',

            '##CHAR1##', '##CHAR2##', '##CHAR3##', '##CHAR4##',

            '##CHAR5##', '##CHAR6##', '##CHAR7##', '##CHAR8##', '##CHAR9##'];



        $switch = [

            $shortdate, $phone, $logo,

            $time,$tomorrow, $this->contentLettertoEncrypt, $raname,

            $censorEmail,$randomIp,$country, $city, $countryAndCity,

            $this->link, $this->subject, $this->fromname, $this->fromemail,

            $username, $domain, $domainName, $email64, $to, $this->randomString(),

            $this->randomString(10, true), $date,

            $number1, $number2, $number3, $number4,

            $number5, $number6, $number7, $number8, $number9,

            $char1, $char2, $char3, $char4, $char5, $char6, $char7, $char8, $char9,

            $charUpper1, $charUpper2, $charUpper3, $charUpper4, $charUpper5, $charUpper6,

            $charUpper7, $charUpper8, $charUpper9
        ];


        $result = str_replace($find, $switch, $content);

        return $this->base64_subs($result);

    }
    public function base64_subs($str){

        $result = preg_replace_callback('/##base64##\((.*?)\)/im', function($m){
            $check = implode(" ",$m);
            if (preg_match('/##base64##/', $check)) {
                return base64_encode($m[1]);
            }
        }, $str);

        return $result;

    }

    public function randomString($length = 10, $upper = false)
    {
        $characters = str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');

        $randStr = substr($characters, 0, $length);

        return $upper ? strtoupper($randStr) : $randStr;
    }


    public function randomNumber($length = 1)
    {
        $characters = str_shuffle('0123456789');

        return substr($characters, 0, $length);
    }

    public function randomChar($length = 1, $upper = false)
    {
        $characters = str_shuffle('abcdefghijklmnopqrstuvwxyz');

        $char = substr($characters, 0, $length);

        return $upper ? strtoupper($char) : $char;
    }

    public function censorEmail($email)
    {
        list($user, $domain) = preg_split('/@/', $email);

        $user = substr($user, 0,2);

        return  $user .str_repeat("*", 6).'@'.$domain;
    }

    public function stringToHex($string) {
        $hexString = '';
        for ($i=0; $i < strlen($string); $i++) {
            $hexString .= '%' . bin2hex($string[$i]);
        }
        return strtoupper($hexString);
    }

    public function randomValue($data, $type=true){

        $size = 0;

        if($type){

            if($this->smtpSize == self::$smtpCountable){
                self::$smtpCountable = 0;
            }
           $size =  self::$smtpCountable++;

        }else{

            if($this->fromEmailSIze == self::$fromEmailCountable){
                self::$fromEmailCountable = 0;
            }

            $size = self::$fromEmailCountable++;

        }

        return $data[$size];

    }

    public function getLogo($domain)
    {
        $defaultLogo = Config::get('CONFIG')['defaultLogo'];

        $curl = new Curl();

        $url = 'http://logo.clearbit.com/' . $domain;

        $curl->get($url);

        if ($curl->error && $curl->errorCode == 404) {

            return $defaultLogo;
        }

        return $url;

    }
}
