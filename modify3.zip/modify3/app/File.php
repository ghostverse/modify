<?php


namespace g66k;


class File
{

    public static function open($filename)
    {
          if(Config::get('CONFIG')['emailtest']){
            return file($filename, FILE_IGNORE_NEW_LINES);
          }
          return  array_unique(file($filename, FILE_IGNORE_NEW_LINES));

    }

    public static function save($filename, $data)
    {
        return file_put_contents($filename, $data .PHP_EOL , FILE_APPEND | LOCK_EX);
    }

    public static function openLetter($filename){
        return file_get_contents($filename);
    }

}