<?php

require 'vendor/autoload.php';

use g66k\smtpChecker;
use g66k\NetTool;
use g66k\Config;

if(Config::get('CONFIG')['blacklist']){

    $netTool = new NetTool();
    $netTool->checkMyIP();
    $smtpHost = Config::get('SMTP');
    foreach ($smtpHost as $smtp){

        if($netTool->isBlackListed($smtp['host'])){

         echo "[+] Your Smtp : ".$smtp['host']." is BlackListed. \n";

        }
    }


}
$blacklist = new NetTool();

$checker = new smtpChecker();
$checker->check();







